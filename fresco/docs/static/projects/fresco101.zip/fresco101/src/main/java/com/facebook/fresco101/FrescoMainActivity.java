/*
 * This file provided by Facebook is for non-commercial testing and evaluation
 * purposes only.  Facebook reserves all rights not expressly granted.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
 * FACEBOOK BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */
package com.facebook.fresco101;

import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import com.facebook.drawee.backends.pipeline.Fresco;
import com.facebook.drawee.interfaces.DraweeController;
import com.facebook.drawee.view.SimpleDraweeView;
import com.facebook.imagepipeline.request.ImageRequest;
import com.facebook.imagepipeline.request.ImageRequestBuilder;

public class FrescoMainActivity extends AppCompatActivity {

  private SimpleDraweeView mDraweeView;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.fresco_activity_main);
    mDraweeView = (SimpleDraweeView) findViewById(R.id.simple_drawee_view);
    // Events on EditText
    final EditText editText = (EditText) findViewById(R.id.uri_edit_text);
    editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
      @Override
      public boolean onEditorAction(TextView view, int actionId, KeyEvent keyEvent) {
        final boolean isEnterKeyDown = (actionId == EditorInfo.IME_NULL) &&
                                               (keyEvent.getAction() == KeyEvent.ACTION_DOWN);
        if (isEnterKeyDown || actionId == EditorInfo.IME_ACTION_DONE) {
          // In case of normal Uri
          //updateImageView(Uri.parse(view.getText().toString()));
          // In case of progressive or animation
          updateProgressiveImage(Uri.parse(view.getText().toString()));
        }
        return false;
      }
    });
    findViewById(R.id.clear_uri)
            .setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                editText.getText().clear();
              }
            });
  }

  private void updateImageView(Uri uri) {
    DraweeController controller = Fresco.newDraweeControllerBuilder()
                                          .setUri(uri)
                                          .build();
    mDraweeView.setController(controller);
  }

  private void updateProgressiveImage(Uri uri) {
    ImageRequest request = ImageRequestBuilder.newBuilderWithSource(uri)
                                   .setProgressiveRenderingEnabled(true)
                                   .build();
    DraweeController controller = Fresco.newDraweeControllerBuilder()
                                          .setImageRequest(request)
                                          .build();
    mDraweeView.setController(controller);
  }
}
